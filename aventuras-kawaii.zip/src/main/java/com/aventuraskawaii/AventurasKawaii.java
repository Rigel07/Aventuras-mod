package com.aventuraskawaii;

import com.aventuraskawaii.registry.ModBlocks;
import com.aventuraskawaii.registry.ModEntities;
import com.aventuraskawaii.registry.ModItems;
import com.aventuraskawaii.registry.ModTabs;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(AventurasKawaii.MODID)
public class AventurasKawaii {
    public static final String MODID = "aventuraskawaii";

    public AventurasKawaii() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(bus);
        ModItems.ITEMS.register(bus);
        ModEntities.ENTITIES.register(bus);
        ModTabs.TABS.register(bus);
    }
}
