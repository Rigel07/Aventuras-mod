package com.aventuraskawaii.registry;

import com.aventuraskawaii.AventurasKawaii;
import com.aventuraskawaii.entity.BultitoEntity;
import com.aventuraskawaii.entity.GominolaEntity;
import com.aventuraskawaii.entity.PeluchonEntity;
import com.aventuraskawaii.entity.PulpitoEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, AventurasKawaii.MODID);

    public static final RegistryObject<EntityType<PulpitoEntity>> PULPITO = ENTITIES.register("pulpito",
            () -> EntityType.Builder.of(PulpitoEntity::new, MobCategory.CREATURE)
                    .sized(0.7F, 0.9F).clientTrackingRange(10).build("pulpito"));

    public static final RegistryObject<EntityType<GominolaEntity>> GOMINOLA = ENTITIES.register("gominola",
            () -> EntityType.Builder.of(GominolaEntity::new, MobCategory.CREATURE)
                    .sized(0.6F, 0.9F).clientTrackingRange(10).build("gominola"));

    public static final RegistryObject<EntityType<PeluchonEntity>> PELUCHON = ENTITIES.register("peluchon",
            () -> EntityType.Builder.of(PeluchonEntity::new, MobCategory.CREATURE)
                    .sized(0.9F, 1.5F).clientTrackingRange(10).build("peluchon"));

    public static final RegistryObject<EntityType<BultitoEntity>> BULTITO = ENTITIES.register("bultito",
            () -> EntityType.Builder.of(BultitoEntity::new, MobCategory.CREATURE)
                    .sized(0.6F, 0.9F).clientTrackingRange(10).build("bultito"));
}
