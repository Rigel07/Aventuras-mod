package com.aventuraskawaii.registry;

import com.aventuraskawaii.AventurasKawaii;
import com.aventuraskawaii.block.LinternaFaroBlock;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.DropExperienceBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, AventurasKawaii.MODID);

    /** Mena de la mina de gominolas. */
    public static final RegistryObject<Block> CRISTAL_AZUCAR = BLOCKS.register("cristal_azucar",
            () -> new DropExperienceBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_PINK)
                    .strength(3.0F, 3.0F)
                    .requiresCorrectToolForDrops()
                    .sound(SoundType.AMETHYST)
                    .lightLevel(state -> 6), UniformInt.of(1, 3)));

    /** Lampara del faro: da Poder de Conducto a quien este cerca. */
    public static final RegistryObject<Block> LINTERNA_FARO = BLOCKS.register("linterna_faro",
            () -> new LinternaFaroBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.GOLD)
                    .strength(3.0F, 6.0F)
                    .sound(SoundType.GLASS)
                    .lightLevel(state -> 15)));
}
