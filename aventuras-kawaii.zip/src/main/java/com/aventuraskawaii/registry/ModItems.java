package com.aventuraskawaii.registry;

import com.aventuraskawaii.AventurasKawaii;
import com.aventuraskawaii.item.JarabeItem;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, AventurasKawaii.MODID);

    public static final RegistryObject<Item> AZUCAR_CRISTAL = ITEMS.register("azucar_cristal",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .nutrition(2).saturationMod(0.3F).fast()
                    .effect(() -> new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 200, 0), 1.0F)
                    .build())));

    public static final RegistryObject<Item> JARABE = ITEMS.register("jarabe_gominola",
            () -> new JarabeItem(new Item.Properties().stacksTo(16)
                    .craftRemainder(Items.GLASS_BOTTLE)
                    .food(new FoodProperties.Builder()
                            .nutrition(3).saturationMod(0.4F).alwaysEat()
                            .effect(() -> new MobEffectInstance(MobEffects.JUMP, 1200, 1), 1.0F)
                            .build())));

    public static final RegistryObject<Item> CRISTAL_AZUCAR = ITEMS.register("cristal_azucar",
            () -> new BlockItem(ModBlocks.CRISTAL_AZUCAR.get(), new Item.Properties()));

    public static final RegistryObject<Item> LINTERNA_FARO = ITEMS.register("linterna_faro",
            () -> new BlockItem(ModBlocks.LINTERNA_FARO.get(), new Item.Properties()));

    public static final RegistryObject<Item> PULPITO_EGG = ITEMS.register("pulpito_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.PULPITO, 0xFF9FB0, 0xFFE0E6, new Item.Properties()));

    public static final RegistryObject<Item> GOMINOLA_EGG = ITEMS.register("gominola_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.GOMINOLA, 0xFF5C6C, 0xFFD166, new Item.Properties()));

    public static final RegistryObject<Item> PELUCHON_EGG = ITEMS.register("peluchon_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.PELUCHON, 0xC58B5C, 0xFFD84D, new Item.Properties()));

    public static final RegistryObject<Item> BULTITO_EGG = ITEMS.register("bultito_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.BULTITO, 0xF4E3C3, 0x4ECDC4, new Item.Properties()));
}
