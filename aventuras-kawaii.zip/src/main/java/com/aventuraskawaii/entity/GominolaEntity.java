package com.aventuraskawaii.entity;

import com.aventuraskawaii.entity.ai.StayNearHomeGoal;
import com.aventuraskawaii.registry.ModItems;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;

/**
 * Gominola: osito de gominola de 5 colores que va dando botes por la mina.
 * Si le acercas un frasco de cristal te regala jarabe (cada 2 minutos).
 */
public class GominolaEntity extends CuteMob {
    public static final int VARIANTS = 5;
    private static final EntityDataAccessor<Integer> VARIANT =
            SynchedEntityData.defineId(GominolaEntity.class, EntityDataSerializers.INT);

    private boolean variantSet;
    private int squeezeCooldown;

    public GominolaEntity(EntityType<? extends GominolaEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 10.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.2D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(VARIANT, 0);
    }

    public int getVariant() {
        return Math.floorMod(this.entityData.get(VARIANT), VARIANTS);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Variant", this.entityData.get(VARIANT));
        tag.putBoolean("VariantSet", this.variantSet);
        tag.putInt("Squeeze", this.squeezeCooldown);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.entityData.set(VARIANT, tag.getInt("Variant"));
        this.variantSet = tag.getBoolean("VariantSet");
        this.squeezeCooldown = tag.getInt("Squeeze");
    }

    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty,
                                        MobSpawnType reason, SpawnGroupData data, CompoundTag tag) {
        if (!this.variantSet) {
            this.entityData.set(VARIANT, this.random.nextInt(VARIANTS));
            this.variantSet = true;
        }
        return super.finalizeSpawn(level, difficulty, reason, data, tag);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new PanicGoal(this, 1.4D));
        this.goalSelector.addGoal(2, new StayNearHomeGoal(this, 10.0D, 0.9D));
        this.goalSelector.addGoal(3, new WaterAvoidingRandomStrollGoal(this, 0.7D));
        this.goalSelector.addGoal(4, new LookAtPlayerGoal(this, Player.class, 6.0F));
        this.goalSelector.addGoal(5, new RandomLookAroundGoal(this));
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide) {
            return;
        }
        if (this.squeezeCooldown > 0) {
            this.squeezeCooldown--;
        }
        // botecitos de gominola
        if (this.onGround() && this.random.nextInt(40) == 0) {
            double angle = this.random.nextDouble() * Math.PI * 2.0D;
            this.setDeltaMovement(Math.cos(angle) * 0.18D, 0.42D, Math.sin(angle) * 0.18D);
            this.playSound(SoundEvents.SLIME_JUMP_SMALL, 0.5F, 1.4F);
        }
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        if (held.is(Items.GLASS_BOTTLE)) {
            if (!this.level().isClientSide) {
                if (this.squeezeCooldown <= 0) {
                    this.squeezeCooldown = 2400;
                    if (!player.getAbilities().instabuild) {
                        held.shrink(1);
                    }
                    ItemStack syrup = new ItemStack(ModItems.JARABE.get());
                    if (!player.getInventory().add(syrup)) {
                        player.drop(syrup, false);
                    }
                    this.playSound(SoundEvents.HONEY_BLOCK_SLIDE, 0.8F, 1.4F);
                    ((ServerLevel) this.level()).sendParticles(ParticleTypes.HEART,
                            this.getX(), this.getY() + 1.0D, this.getZ(), 4, 0.3D, 0.2D, 0.3D, 0.02D);
                } else {
                    player.displayClientMessage(
                            Component.translatable("message.aventuraskawaii.gominola.espera"), true);
                }
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        return super.mobInteract(player, hand);
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.SLIME_HURT_SMALL;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.SLIME_DEATH_SMALL;
    }
}
