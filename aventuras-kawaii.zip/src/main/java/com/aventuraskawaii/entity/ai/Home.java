package com.aventuraskawaii.entity.ai;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.Entity;

/** Recuerda la estructura donde nacio el mob. */
public final class Home {
    private static final String KEY = "aventuras_home";

    private Home() {
    }

    public static void set(Entity entity, BlockPos pos) {
        entity.getPersistentData().putLong(KEY, pos.asLong());
    }

    public static BlockPos get(Entity entity) {
        CompoundTag tag = entity.getPersistentData();
        return tag.contains(KEY) ? BlockPos.of(tag.getLong(KEY)) : null;
    }
}
