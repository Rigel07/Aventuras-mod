package com.aventuraskawaii.entity;

import com.aventuraskawaii.entity.ai.StayNearHomeGoal;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.pathfinder.BlockPathTypes;

/**
 * Pulpito, pescador del faro: mientras esta en el agua va sacando solo peces y
 * tesoritos del mar. Basta con recoger lo que suelta.
 */
public class PulpitoEntity extends CuteMob {
    private static final Item[] CATCH = {
            Items.COD, Items.SALMON, Items.TROPICAL_FISH, Items.PUFFERFISH, Items.KELP, Items.INK_SAC,
            Items.LILY_PAD, Items.SEA_PICKLE, Items.PRISMARINE_SHARD, Items.GLOW_INK_SAC,
            Items.NAUTILUS_SHELL, Items.NAME_TAG
    };
    private static final int[] WEIGHT = {30, 22, 8, 6, 8, 8, 6, 5, 5, 3, 2, 1};

    private int catchTime;

    public PulpitoEntity(EntityType<? extends PulpitoEntity> type, Level level) {
        super(type, level);
        this.setPathfindingMalus(BlockPathTypes.WATER, 0.0F);
        this.catchTime = 1800 + this.random.nextInt(1800);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 12.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.2D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new PanicGoal(this, 1.3D));
        this.goalSelector.addGoal(2, new StayNearHomeGoal(this, 6.0D, 0.8D));
        this.goalSelector.addGoal(3, new RandomStrollGoal(this, 0.6D, 100));
        this.goalSelector.addGoal(4, new LookAtPlayerGoal(this, Player.class, 6.0F));
        this.goalSelector.addGoal(5, new RandomLookAroundGoal(this));
    }

    private ItemStack pickCatch() {
        int total = 0;
        for (int w : WEIGHT) {
            total += w;
        }
        int roll = this.random.nextInt(total);
        for (int i = 0; i < CATCH.length; i++) {
            roll -= WEIGHT[i];
            if (roll < 0) {
                return new ItemStack(CATCH[i], CATCH[i] == Items.KELP ? 1 + this.random.nextInt(3) : 1);
            }
        }
        return new ItemStack(Items.COD);
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide || !this.isInWater()) {
            return;
        }
        if (this.catchTime > 0) {
            this.catchTime--;
        } else {
            this.catchTime = 3000 + this.random.nextInt(3000);
            this.spawnAtLocation(this.pickCatch());
            this.playSound(SoundEvents.FISHING_BOBBER_SPLASH, 0.8F, 1.3F);
            ((ServerLevel) this.level()).sendParticles(ParticleTypes.BUBBLE_POP,
                    this.getX(), this.getY() + 0.8D, this.getZ(), 8, 0.3D, 0.2D, 0.3D, 0.01D);
        }
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.DOLPHIN_AMBIENT_WATER;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.DOLPHIN_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.DOLPHIN_DEATH;
    }
}
