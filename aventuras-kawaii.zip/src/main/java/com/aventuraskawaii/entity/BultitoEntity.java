package com.aventuraskawaii.entity;

import com.aventuraskawaii.entity.ai.StayNearHomeGoal;
import java.util.EnumSet;
import java.util.UUID;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

/**
 * Bultito: criatura exploradora con una mochila enorme. Si le das una manzana,
 * bayas dulces o una zanahoria dorada puede encariniarse contigo: te sigue a
 * todas partes y, al hacerle clic derecho con la mano vacia, abre su mochila
 * (27 huecos).
 */
public class BultitoEntity extends CuteMob {
    private final SimpleContainer backpack = new SimpleContainer(27);
    private UUID owner;

    public BultitoEntity(EntityType<? extends BultitoEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 16.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.26D);
    }

    public boolean isTamed() {
        return this.owner != null;
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new PanicGoal(this, 1.3D));
        this.goalSelector.addGoal(2, new FollowOwner());
        this.goalSelector.addGoal(3, new StayNearHomeGoal(this, 9.0D, 0.7D) {
            @Override
            public boolean canUse() {
                return !isTamed() && super.canUse();
            }
        });
        this.goalSelector.addGoal(4, new WaterAvoidingRandomStrollGoal(this, 0.6D));
        this.goalSelector.addGoal(5, new LookAtPlayerGoal(this, Player.class, 6.0F));
        this.goalSelector.addGoal(6, new RandomLookAroundGoal(this));
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        if (this.owner == null) {
            if (held.is(Items.APPLE) || held.is(Items.SWEET_BERRIES) || held.is(Items.GOLDEN_CARROT)) {
                if (!this.level().isClientSide) {
                    if (!player.getAbilities().instabuild) {
                        held.shrink(1);
                    }
                    if (this.random.nextInt(3) == 0) {
                        this.owner = player.getUUID();
                        this.showHearts();
                    } else {
                        ((ServerLevel) this.level()).sendParticles(ParticleTypes.SMOKE,
                                this.getX(), this.getY() + 0.8D, this.getZ(), 6, 0.3D, 0.2D, 0.3D, 0.01D);
                    }
                }
                return InteractionResult.sidedSuccess(this.level().isClientSide);
            }
        } else if (player.getUUID().equals(this.owner) && held.isEmpty() && hand == InteractionHand.MAIN_HAND) {
            if (!this.level().isClientSide) {
                player.openMenu(new SimpleMenuProvider(
                        (id, inventory, p) -> ChestMenu.threeRows(id, inventory, this.backpack),
                        this.getDisplayName()));
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        return super.mobInteract(player, hand);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (this.owner != null) {
            tag.putUUID("Owner", this.owner);
        }
        tag.put("Backpack", this.backpack.createTag());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.hasUUID("Owner")) {
            this.owner = tag.getUUID("Owner");
        }
        this.backpack.fromTag(tag.getList("Backpack", 10));
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (!this.level().isClientSide) {
            Containers.dropContents(this.level(), this.blockPosition(), this.backpack);
        }
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.CAT_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.CAT_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.CAT_DEATH;
    }

    /** Sigue a su dueno y se teletransporta a su lado si se queda muy atras. */
    private class FollowOwner extends Goal {
        private Player target;
        private int recalc;

        FollowOwner() {
            this.setFlags(EnumSet.of(Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            if (owner == null) {
                return false;
            }
            Player player = level().getPlayerByUUID(owner);
            if (player == null || player.isSpectator()) {
                return false;
            }
            if (distanceToSqr(player) < 25.0D) {
                return false;
            }
            this.target = player;
            return true;
        }

        @Override
        public boolean canContinueToUse() {
            return this.target != null && this.target.isAlive() && distanceToSqr(this.target) > 9.0D;
        }

        @Override
        public void start() {
            this.recalc = 0;
        }

        @Override
        public void tick() {
            if (distanceToSqr(this.target) > 24.0D * 24.0D) {
                teleportTo(this.target.getX() + 1.0D, this.target.getY(), this.target.getZ() + 1.0D);
                getNavigation().stop();
                return;
            }
            if (--this.recalc <= 0) {
                this.recalc = 10;
                getNavigation().moveTo(this.target, 1.15D);
            }
        }
    }
}
