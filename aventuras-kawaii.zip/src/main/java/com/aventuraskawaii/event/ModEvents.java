package com.aventuraskawaii.event;

import com.aventuraskawaii.AventurasKawaii;
import com.aventuraskawaii.entity.BultitoEntity;
import com.aventuraskawaii.entity.GominolaEntity;
import com.aventuraskawaii.entity.PeluchonEntity;
import com.aventuraskawaii.entity.PulpitoEntity;
import com.aventuraskawaii.registry.ModEntities;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = AventurasKawaii.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModEvents {

    @SubscribeEvent
    public static void onAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.PULPITO.get(), PulpitoEntity.createAttributes().build());
        event.put(ModEntities.GOMINOLA.get(), GominolaEntity.createAttributes().build());
        event.put(ModEntities.PELUCHON.get(), PeluchonEntity.createAttributes().build());
        event.put(ModEntities.BULTITO.get(), BultitoEntity.createAttributes().build());
    }
}
