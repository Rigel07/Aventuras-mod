package com.aventuraskawaii.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

/**
 * Linterna del faro: cualquier jugador a menos de ~30 bloques recibe Poder de
 * Conducto (respirar bajo el agua, ver y picar mejor). En el agua, ademas,
 * Gracia del Delfin.
 */
public class LinternaFaroBlock extends Block {

    public LinternaFaroBlock(Properties properties) {
        super(properties);
    }

    @Override
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean moving) {
        if (!level.isClientSide) {
            level.scheduleTick(pos, this, 20);
        }
    }

    // En la generacion del mundo no se llama a onPlace: los ticks aleatorios arrancan el ciclo.
    @Override
    public boolean isRandomlyTicking(BlockState state) {
        return true;
    }

    @Override
    public void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        level.scheduleTick(pos, this, 20);
    }

    @Override
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        AABB area = new AABB(pos).inflate(30.0D, 24.0D, 30.0D);
        for (Player player : level.getEntitiesOfClass(Player.class, area)) {
            player.addEffect(new MobEffectInstance(MobEffects.CONDUIT_POWER, 260, 0, true, false));
            if (player.isInWater()) {
                player.addEffect(new MobEffectInstance(MobEffects.DOLPHINS_GRACE, 260, 0, true, false));
            }
        }
        level.sendParticles(ParticleTypes.GLOW, pos.getX() + 0.5D, pos.getY() + 1.2D, pos.getZ() + 0.5D,
                2, 0.3D, 0.2D, 0.3D, 0.0D);
        level.scheduleTick(pos, this, 80);
    }
}
