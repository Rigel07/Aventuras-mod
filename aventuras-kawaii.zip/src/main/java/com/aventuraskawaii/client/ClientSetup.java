package com.aventuraskawaii.client;

import com.aventuraskawaii.AventurasKawaii;
import com.aventuraskawaii.entity.BultitoEntity;
import com.aventuraskawaii.entity.GominolaEntity;
import com.aventuraskawaii.entity.PeluchonEntity;
import com.aventuraskawaii.entity.PulpitoEntity;
import com.aventuraskawaii.registry.ModEntities;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = AventurasKawaii.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {

    private static ResourceLocation tex(String name) {
        return new ResourceLocation(AventurasKawaii.MODID, "textures/entity/" + name + ".png");
    }

    private static final ResourceLocation[] GOMINOLAS = {
            tex("gominola_0"), tex("gominola_1"), tex("gominola_2"), tex("gominola_3"), tex("gominola_4")
    };

    @SubscribeEvent
    public static void registerLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(AventuraModel.OCTO_LAYER, AventuraModel::createOcto);
        event.registerLayerDefinition(AventuraModel.GUMMY_LAYER, AventuraModel::createGummy);
        event.registerLayerDefinition(AventuraModel.BEAR_LAYER, AventuraModel::createBear);
        event.registerLayerDefinition(AventuraModel.PACK_LAYER, AventuraModel::createPack);
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.PULPITO.get(),
                ctx -> new AventuraRenderer<PulpitoEntity>(ctx,
                        new AventuraModel<PulpitoEntity>(ctx.bakeLayer(AventuraModel.OCTO_LAYER), AventuraModel.Kind.OCTO),
                        0.45F, 0.9F, e -> tex("pulpito")));
        event.registerEntityRenderer(ModEntities.GOMINOLA.get(),
                ctx -> new AventuraRenderer<GominolaEntity>(ctx,
                        new AventuraModel<GominolaEntity>(ctx.bakeLayer(AventuraModel.GUMMY_LAYER), AventuraModel.Kind.GUMMY),
                        0.35F, 0.85F, e -> GOMINOLAS[e.getVariant()]));
        event.registerEntityRenderer(ModEntities.PELUCHON.get(),
                ctx -> new AventuraRenderer<PeluchonEntity>(ctx,
                        new AventuraModel<PeluchonEntity>(ctx.bakeLayer(AventuraModel.BEAR_LAYER), AventuraModel.Kind.BEAR),
                        0.6F, 1.0F, e -> tex("peluchon")));
        event.registerEntityRenderer(ModEntities.BULTITO.get(),
                ctx -> new AventuraRenderer<BultitoEntity>(ctx,
                        new AventuraModel<BultitoEntity>(ctx.bakeLayer(AventuraModel.PACK_LAYER), AventuraModel.Kind.PACK),
                        0.4F, 0.85F, e -> tex("bultito")));
    }
}
