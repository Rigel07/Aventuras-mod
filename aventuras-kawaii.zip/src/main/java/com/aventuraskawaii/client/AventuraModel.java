package com.aventuraskawaii.client;

import com.aventuraskawaii.AventurasKawaii;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;

/**
 * Modelo compartido por los cuatro mobs (pulpito, gominola, osito y bultito).
 * Partes fijas: head (hx1..hx3), body, arm_l, arm_r, leg_l, leg_r, x1..x4.
 */
public class AventuraModel<T extends Entity> extends EntityModel<T> {

    public enum Kind { OCTO, GUMMY, BEAR, PACK }

    public static final ModelLayerLocation OCTO_LAYER = layer("pulpito");
    public static final ModelLayerLocation GUMMY_LAYER = layer("gominola");
    public static final ModelLayerLocation BEAR_LAYER = layer("peluchon");
    public static final ModelLayerLocation PACK_LAYER = layer("bultito");

    private static ModelLayerLocation layer(String name) {
        return new ModelLayerLocation(new ResourceLocation(AventurasKawaii.MODID, name), "main");
    }

    private final ModelPart root;
    private final ModelPart head;
    private final ModelPart armL;
    private final ModelPart armR;
    private final ModelPart legL;
    private final ModelPart legR;
    private final ModelPart x1;
    private final ModelPart x2;
    private final ModelPart x3;
    private final ModelPart x4;
    private final Kind kind;

    public AventuraModel(ModelPart root, Kind kind) {
        this.root = root;
        this.kind = kind;
        this.head = root.getChild("head");
        this.armL = root.getChild("arm_l");
        this.armR = root.getChild("arm_r");
        this.legL = root.getChild("leg_l");
        this.legR = root.getChild("leg_r");
        this.x1 = root.getChild("x1");
        this.x2 = root.getChild("x2");
        this.x3 = root.getChild("x3");
        this.x4 = root.getChild("x4");
    }

    private static PartDefinition empty(PartDefinition parent, String name) {
        return parent.addOrReplaceChild(name, CubeListBuilder.create(), PartPose.ZERO);
    }

    private static void part(PartDefinition parent, String name, int u, int v, boolean mirror,
                             float x, float y, float z, float w, float h, float d, PartPose pose) {
        CubeListBuilder builder = CubeListBuilder.create().texOffs(u, v);
        if (mirror) {
            builder = builder.mirror();
        }
        parent.addOrReplaceChild(name, builder.addBox(x, y, z, w, h, d), pose);
    }

    /** Pulpito: cabeza-manto enorme y ocho tentaculos. */
    public static LayerDefinition createOcto() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition r = mesh.getRoot();
        PartDefinition head = r.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F),
                PartPose.offset(0.0F, 17.0F, 0.0F));
        part(head, "hx1", 32, 0, false, -3.0F, -11.0F, -3.0F, 6.0F, 3.0F, 6.0F, PartPose.ZERO);
        empty(head, "hx2");
        empty(head, "hx3");
        part(r, "body", 0, 16, false, -3.0F, 0.0F, -3.0F, 6.0F, 3.0F, 6.0F, PartPose.offset(0.0F, 17.0F, 0.0F));
        float k = 2.1F;
        part(r, "arm_l", 0, 28, false, -1.0F, 0.0F, -1.0F, 2.0F, 4.0F, 2.0F, PartPose.offset(k, 20.0F, -k));
        part(r, "arm_r", 0, 28, false, -1.0F, 0.0F, -1.0F, 2.0F, 4.0F, 2.0F, PartPose.offset(-k, 20.0F, -k));
        part(r, "leg_l", 0, 28, false, -1.0F, 0.0F, -1.0F, 2.0F, 4.0F, 2.0F, PartPose.offset(k, 20.0F, k));
        part(r, "leg_r", 0, 28, false, -1.0F, 0.0F, -1.0F, 2.0F, 4.0F, 2.0F, PartPose.offset(-k, 20.0F, k));
        part(r, "x1", 0, 28, false, -1.0F, 0.0F, -1.0F, 2.0F, 4.0F, 2.0F, PartPose.offset(0.0F, 20.0F, -3.0F));
        part(r, "x2", 0, 28, false, -1.0F, 0.0F, -1.0F, 2.0F, 4.0F, 2.0F, PartPose.offset(3.0F, 20.0F, 0.0F));
        part(r, "x3", 0, 28, false, -1.0F, 0.0F, -1.0F, 2.0F, 4.0F, 2.0F, PartPose.offset(0.0F, 20.0F, 3.0F));
        part(r, "x4", 0, 28, false, -1.0F, 0.0F, -1.0F, 2.0F, 4.0F, 2.0F, PartPose.offset(-3.0F, 20.0F, 0.0F));
        return LayerDefinition.create(mesh, 64, 64);
    }

    /** Gominola: osito rechoncho con orejitas redondas. */
    public static LayerDefinition createGummy() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition r = mesh.getRoot();
        PartDefinition head = r.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -7.0F, -4.0F, 8.0F, 7.0F, 8.0F),
                PartPose.offset(0.0F, 15.0F, 0.0F));
        part(head, "hx1", 32, 0, false, -1.5F, -1.5F, -0.5F, 3.0F, 3.0F, 1.0F, PartPose.offset(-3.0F, -7.0F, 0.0F));
        part(head, "hx2", 32, 0, true, -1.5F, -1.5F, -0.5F, 3.0F, 3.0F, 1.0F, PartPose.offset(3.0F, -7.0F, 0.0F));
        empty(head, "hx3");
        part(r, "body", 0, 16, false, -3.5F, 0.0F, -2.5F, 7.0F, 6.0F, 5.0F, PartPose.offset(0.0F, 15.0F, 0.0F));
        part(r, "arm_r", 24, 16, false, -1.0F, 0.0F, -1.0F, 2.0F, 4.0F, 2.0F, PartPose.offset(-4.5F, 15.5F, 0.0F));
        part(r, "arm_l", 24, 16, true, -1.0F, 0.0F, -1.0F, 2.0F, 4.0F, 2.0F, PartPose.offset(4.5F, 15.5F, 0.0F));
        part(r, "leg_r", 40, 16, false, -1.5F, 0.0F, -1.5F, 3.0F, 3.0F, 3.0F, PartPose.offset(-2.0F, 21.0F, 0.0F));
        part(r, "leg_l", 40, 16, true, -1.5F, 0.0F, -1.5F, 3.0F, 3.0F, 3.0F, PartPose.offset(2.0F, 21.0F, 0.0F));
        empty(r, "x1");
        empty(r, "x2");
        empty(r, "x3");
        empty(r, "x4");
        return LayerDefinition.create(mesh, 64, 64);
    }

    /** Peluchon: osito de peluche con corona y pajarita. */
    public static LayerDefinition createBear() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition r = mesh.getRoot();
        PartDefinition head = r.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F)
                        .texOffs(32, 0).addBox(-2.0F, -3.0F, -6.0F, 4.0F, 3.0F, 2.0F),
                PartPose.offset(0.0F, 9.0F, 0.0F));
        part(head, "hx1", 32, 8, false, -1.5F, -1.5F, -1.0F, 3.0F, 3.0F, 2.0F, PartPose.offset(-3.0F, -8.0F, 0.0F));
        part(head, "hx2", 32, 8, true, -1.5F, -1.5F, -1.0F, 3.0F, 3.0F, 2.0F, PartPose.offset(3.0F, -8.0F, 0.0F));
        part(head, "hx3", 0, 44, false, -3.0F, -11.0F, -3.0F, 6.0F, 3.0F, 6.0F, PartPose.ZERO);
        part(r, "body", 0, 16, false, -4.0F, 0.0F, -2.5F, 8.0F, 9.0F, 5.0F, PartPose.offset(0.0F, 9.0F, 0.0F));
        part(r, "arm_r", 28, 16, false, -1.5F, -1.0F, -1.5F, 3.0F, 8.0F, 3.0F, PartPose.offset(-5.5F, 10.0F, 0.0F));
        part(r, "arm_l", 28, 16, true, -1.5F, -1.0F, -1.5F, 3.0F, 8.0F, 3.0F, PartPose.offset(5.5F, 10.0F, 0.0F));
        part(r, "leg_r", 40, 16, false, -1.5F, 0.0F, -1.5F, 3.0F, 6.0F, 3.0F, PartPose.offset(-2.0F, 18.0F, 0.0F));
        part(r, "leg_l", 40, 16, true, -1.5F, 0.0F, -1.5F, 3.0F, 6.0F, 3.0F, PartPose.offset(2.0F, 18.0F, 0.0F));
        part(r, "x1", 52, 16, false, -1.5F, -1.5F, 0.0F, 3.0F, 3.0F, 2.0F, PartPose.offset(0.0F, 16.0F, 2.5F));
        part(r, "x2", 52, 24, false, -2.0F, 0.0F, -0.5F, 4.0F, 2.0F, 1.0F, PartPose.offset(0.0F, 9.5F, -2.6F));
        empty(r, "x3");
        empty(r, "x4");
        return LayerDefinition.create(mesh, 64, 64);
    }

    /** Bultito: bichito con una mochila de exploracion gigante. */
    public static LayerDefinition createPack() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition r = mesh.getRoot();
        PartDefinition head = r.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -7.0F, -4.0F, 8.0F, 7.0F, 8.0F),
                PartPose.offset(0.0F, 16.0F, 0.0F));
        part(head, "hx1", 32, 0, false, -1.5F, -2.0F, -0.5F, 3.0F, 2.0F, 1.0F, PartPose.offset(-3.0F, -7.0F, 0.0F));
        part(head, "hx2", 32, 0, true, -1.5F, -2.0F, -0.5F, 3.0F, 2.0F, 1.0F, PartPose.offset(3.0F, -7.0F, 0.0F));
        empty(head, "hx3");
        part(r, "body", 0, 16, false, -3.0F, 0.0F, -2.0F, 6.0F, 5.0F, 4.0F, PartPose.offset(0.0F, 16.0F, 0.0F));
        part(r, "arm_r", 20, 16, false, -1.0F, 0.0F, -1.0F, 2.0F, 4.0F, 2.0F, PartPose.offset(-4.0F, 16.5F, 0.0F));
        part(r, "arm_l", 20, 16, true, -1.0F, 0.0F, -1.0F, 2.0F, 4.0F, 2.0F, PartPose.offset(4.0F, 16.5F, 0.0F));
        part(r, "leg_r", 36, 16, false, -1.0F, 0.0F, -1.5F, 2.0F, 3.0F, 3.0F, PartPose.offset(-1.5F, 21.0F, 0.0F));
        part(r, "leg_l", 36, 16, true, -1.0F, 0.0F, -1.5F, 2.0F, 3.0F, 3.0F, PartPose.offset(1.5F, 21.0F, 0.0F));
        part(r, "x1", 0, 28, false, -4.0F, -1.0F, 0.0F, 8.0F, 8.0F, 5.0F, PartPose.offset(0.0F, 16.0F, 2.0F));
        part(r, "x2", 28, 28, false, -3.5F, -2.0F, 0.0F, 7.0F, 2.0F, 5.0F, PartPose.offset(0.0F, 15.0F, 2.0F));
        part(r, "x3", 28, 36, false, -2.0F, 0.0F, 0.0F, 4.0F, 3.0F, 2.0F, PartPose.offset(0.0F, 19.0F, 7.0F));
        part(r, "x4", 0, 44, false, -4.5F, -3.0F, -1.5F, 9.0F, 3.0F, 3.0F, PartPose.offset(0.0F, 14.5F, 3.5F));
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        this.head.yRot = netHeadYaw * ((float) Math.PI / 180F);
        this.head.xRot = headPitch * ((float) Math.PI / 180F);
        float swing = Mth.cos(limbSwing * 0.6662F) * 1.2F * limbSwingAmount;
        float sway = Mth.sin(ageInTicks * 0.09F);

        switch (this.kind) {
            case OCTO -> {
                ModelPart[] tentacles = {this.armL, this.armR, this.legL, this.legR, this.x1, this.x2, this.x3, this.x4};
                for (int i = 0; i < tentacles.length; i++) {
                    float phase = ageInTicks * 0.12F + i * 0.8F;
                    tentacles[i].xRot = Mth.sin(phase) * 0.18F + swing * (i % 2 == 0 ? 0.5F : -0.5F);
                    tentacles[i].zRot = Mth.cos(phase) * 0.1F;
                }
            }
            case GUMMY -> {
                this.armL.zRot = -0.2F - sway * 0.2F;
                this.armR.zRot = 0.2F + sway * 0.2F;
                this.legL.xRot = swing;
                this.legR.xRot = -swing;
            }
            case BEAR -> {
                boolean fighting = entity instanceof Mob mob && mob.isAggressive();
                if (fighting) {
                    this.armL.xRot = -1.6F + swing * 0.3F;
                    this.armR.xRot = -1.6F - swing * 0.3F;
                } else {
                    this.armL.xRot = -swing;
                    this.armR.xRot = swing;
                    this.armL.zRot = -0.05F - sway * 0.04F;
                    this.armR.zRot = 0.05F + sway * 0.04F;
                }
                this.legL.xRot = swing;
                this.legR.xRot = -swing;
            }
            default -> {
                this.legL.xRot = swing;
                this.legR.xRot = -swing;
                this.armL.xRot = -swing;
                this.armR.xRot = swing;
                this.x3.xRot = Mth.sin(ageInTicks * 0.1F) * 0.04F;
            }
        }
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        this.root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
