# Aventuras Kawaii (Forge 1.20.1)

| Estructura | Mob | Mecanica |
|---|---|---|
| Faro de las Olas (playas) | Pulpito | Pesca solo en su estanque. La Linterna del Faro da Poder de Conducto |
| Mina de Gominolas (llanuras, bosques, colinas) | Gominola | Mina con vias y vagonetas, mena de Cristal de Azucar. Con un frasco da Jarabe |
| Castillo de Peluche (llanuras, prados, cerezos) | Peluchon | Osito guardian que defiende de monstruos. Taller, armeria, tesoro y mazmorra |
| Campamento de Exploradores (bosques, taigas) | Bultito | Se domestica y carga una mochila de 27 huecos |

Compilar: `gradle build` (Java 17, Gradle 8.1.1). El .jar queda en `build/libs/`.
Probar: `/locate structure aventuraskawaii:faro` (o `mina`, `castillo`, `campamento`).
